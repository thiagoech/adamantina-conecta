import { z } from 'zod'

export const registerSchema = z.object({
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres'),
  email: z.string().email('E-mail inválido'),
  password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres'),
  role: z.enum(['client', 'provider']),
  phone: z.string().optional(),
})

export const loginSchema = z.object({
  email: z.string().email('E-mail inválido'),
  password: z.string().min(1, 'Senha é obrigatória'),
})

export const serviceRequestSchema = z.object({
  title: z.string().min(5, 'Título deve ter pelo menos 5 caracteres'),
  description: z.string().min(20, 'Descrição deve ter pelo menos 20 caracteres'),
  categoryId: z.string().min(1, 'Selecione uma categoria'),
  location: z.string().min(5, 'Informe o endereço completo'),
  price: z.number().positive('Preço deve ser positivo').optional(),
  scheduledAt: z.string().optional(),
})

export const reviewSchema = z.object({
  rating: z.number().min(1).max(5),
  comment: z.string().min(10, 'Comentário deve ter pelo menos 10 caracteres').optional(),
  serviceId: z.string().min(1),
  providerId: z.string().min(1),
})

export const paymentSchema = z.object({
  serviceId: z.string().min(1),
  method: z.enum(['pix', 'card']),
  amount: z.number().positive(),
})

export const profileUpdateSchema = z.object({
  name: z.string().min(2).optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  bio: z.string().optional(),
  skills: z.array(z.string()).optional(),
})

export type RegisterInput = z.infer<typeof registerSchema>
export type LoginInput = z.infer<typeof loginSchema>
export type ServiceRequestInput = z.infer<typeof serviceRequestSchema>
export type ReviewInput = z.infer<typeof reviewSchema>
export type PaymentInput = z.infer<typeof paymentSchema>
export type ProfileUpdateInput = z.infer<typeof profileUpdateSchema>
