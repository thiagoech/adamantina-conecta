import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StatusBadge from '@/components/ui/StatusBadge'
import Link from 'next/link'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      serviceRequests: {
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { category: true, provider: { include: { user: true } } },
      },
      notifications: {
        where: { read: false },
        take: 5,
        orderBy: { createdAt: 'desc' },
      },
      provider: {
        include: {
          services: {
            take: 5,
            orderBy: { createdAt: 'desc' },
            include: { category: true, client: true },
          },
        },
      },
    },
  })

  if (!user) redirect('/login')

  const isProvider = user.role === 'provider' && user.provider

  const stats = isProvider ? {
    total: await prisma.serviceRequest.count({ where: { providerId: user.provider!.id } }),
    open: await prisma.serviceRequest.count({ where: { providerId: user.provider!.id, status: 'open' } }),
    completed: await prisma.serviceRequest.count({ where: { providerId: user.provider!.id, status: 'completed' } }),
    earnings: await prisma.serviceRequest.aggregate({
      where: { providerId: user.provider!.id, status: 'completed' },
      _sum: { price: true },
    }),
  } : {
    total: await prisma.serviceRequest.count({ where: { clientId: user.id } }),
    open: await prisma.serviceRequest.count({ where: { clientId: user.id, status: 'open' } }),
    completed: await prisma.serviceRequest.count({ where: { clientId: user.id, status: 'completed' } }),
    spent: await prisma.payment.aggregate({
      where: { clientId: user.id, status: 'completed' },
      _sum: { amount: true },
    }),
  }

  const requests = isProvider ? user.provider!.services : user.serviceRequests

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Olá, {user.name?.split(' ')[0]}! 👋
            </h1>
            <p className="text-gray-500 mt-1">
              {isProvider ? 'Painel do prestador' : 'Painel do cliente'}
            </p>
          </div>
          {!isProvider && (
            <Link href="/solicitacoes/nova" className="btn-primary">
              + Nova Solicitação
            </Link>
          )}
        </div>

        {/* Notifications */}
        {user.notifications.length > 0 && (
          <div className="mb-6 space-y-2">
            {user.notifications.map((notif) => (
              <div key={notif.id} className={`flex items-center gap-3 p-4 rounded-xl border ${
                notif.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-sky-50 border-sky-200'
              }`}>
                <span>{notif.type === 'success' ? '✅' : 'ℹ️'}</span>
                <p className="text-sm text-gray-700 flex-1">{notif.message}</p>
                <span className="text-xs text-gray-400">{new Date(notif.createdAt).toLocaleDateString('pt-BR')}</span>
              </div>
            ))}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card p-5">
            <p className="text-sm text-gray-500">Total de pedidos</p>
            <p className="text-3xl font-extrabold text-gray-900 mt-1">{(stats as any).total}</p>
          </div>
          <div className="card p-5">
            <p className="text-sm text-gray-500">Em aberto</p>
            <p className="text-3xl font-extrabold text-sky-600 mt-1">{(stats as any).open}</p>
          </div>
          <div className="card p-5">
            <p className="text-sm text-gray-500">Concluídos</p>
            <p className="text-3xl font-extrabold text-emerald-600 mt-1">{(stats as any).completed}</p>
          </div>
          <div className="card p-5">
            <p className="text-sm text-gray-500">{isProvider ? 'Ganhos totais' : 'Total gasto'}</p>
            <p className="text-3xl font-extrabold text-purple-600 mt-1">
              R$ {((isProvider ? (stats as any).earnings?._sum?.price : (stats as any).spent?._sum?.amount) || 0).toFixed(2)}
            </p>
          </div>
        </div>

        {/* Rating (for providers) */}
        {isProvider && user.provider && (
          <div className="card p-5 mb-6 flex items-center gap-4">
            <div className="text-4xl">⭐</div>
            <div>
              <p className="text-sm text-gray-500">Sua avaliação média</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-extrabold text-gray-900">{user.provider.rating.toFixed(1)}</span>
                <div className="flex">
                  {[1,2,3,4,5].map(s => (
                    <span key={s} className={`text-lg ${s <= Math.round(user.provider!.rating) ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                  ))}
                </div>
                <span className="text-gray-400 text-sm">({user.provider.totalReviews} avaliações)</span>
              </div>
            </div>
            <div className="ml-auto flex gap-2">
              {user.provider.verified ? (
                <span className="bg-green-100 text-green-700 text-sm px-3 py-1 rounded-full font-medium">✓ Verificado</span>
              ) : (
                <span className="bg-yellow-100 text-yellow-700 text-sm px-3 py-1 rounded-full font-medium">Aguardando verificação</span>
              )}
            </div>
          </div>
        )}

        {/* Recent Requests */}
        <div className="card overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-bold text-gray-900">
              {isProvider ? 'Solicitações recebidas' : 'Minhas solicitações'}
            </h2>
            <Link href="/solicitacoes" className="text-sky-600 text-sm hover:underline">Ver todas →</Link>
          </div>
          {requests.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <span className="text-4xl block mb-2">📋</span>
              <p>Nenhuma solicitação ainda.</p>
              {!isProvider && (
                <Link href="/solicitacoes/nova" className="text-sky-600 text-sm mt-2 hover:underline inline-block">Criar primeira solicitação</Link>
              )}
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {requests.map((req: any) => (
                <Link key={req.id} href={`/solicitacoes/${req.id}`} className="block px-6 py-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-gray-900 truncate">{req.title}</p>
                        <StatusBadge status={req.status} />
                      </div>
                      <p className="text-sm text-gray-500 mt-0.5 truncate">
                        {req.category?.name} · {isProvider ? req.client?.name : req.provider?.user?.name || 'Sem prestador'}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      {req.price && <p className="font-semibold text-gray-900">R$ {req.price.toFixed(2)}</p>}
                      <p className="text-xs text-gray-400">{new Date(req.createdAt).toLocaleDateString('pt-BR')}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
          {!isProvider && (
            <Link href="/solicitacoes/nova" className="card p-4 text-center hover:shadow-md transition-all hover:border-sky-200">
              <span className="text-3xl block mb-2">📝</span>
              <p className="text-sm font-medium text-gray-700">Nova Solicitação</p>
            </Link>
          )}
          <Link href="/catalogo" className="card p-4 text-center hover:shadow-md transition-all hover:border-sky-200">
            <span className="text-3xl block mb-2">🔍</span>
            <p className="text-sm font-medium text-gray-700">Explorar Serviços</p>
          </Link>
          <Link href="/solicitacoes" className="card p-4 text-center hover:shadow-md transition-all hover:border-sky-200">
            <span className="text-3xl block mb-2">📋</span>
            <p className="text-sm font-medium text-gray-700">Minhas Solicitações</p>
          </Link>
          <Link href="/perfil" className="card p-4 text-center hover:shadow-md transition-all hover:border-sky-200">
            <span className="text-3xl block mb-2">👤</span>
            <p className="text-sm font-medium text-gray-700">Meu Perfil</p>
          </Link>
        </div>
      </div>
    </div>
  )
}
