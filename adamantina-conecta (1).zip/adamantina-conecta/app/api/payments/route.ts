import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { paymentSchema } from '@/lib/validations'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const body = await req.json()
    const parsed = paymentSchema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 })
    }

    const { serviceId, method, amount } = parsed.data

    // Verify service ownership
    const service = await prisma.serviceRequest.findUnique({
      where: { id: serviceId },
      include: { payments: true },
    })

    if (!service) return NextResponse.json({ error: 'Serviço não encontrado.' }, { status: 404 })
    if (service.clientId !== session.user.id) return NextResponse.json({ error: 'Sem permissão.' }, { status: 403 })
    if (service.status !== 'completed') return NextResponse.json({ error: 'O serviço precisa estar concluído.' }, { status: 400 })

    const alreadyPaid = service.payments.some(p => p.status === 'completed')
    if (alreadyPaid) return NextResponse.json({ error: 'Este serviço já foi pago.' }, { status: 400 })

    // Simulate payment processing (in production: integrate Mercado Pago / Stripe)
    const pixCode = method === 'pix'
      ? `00020126580014br.gov.bcb.pix0136adamantina-conecta-pix-key5204000053039865406${amount.toFixed(2).replace('.', '')}5802BR5925ADAMANTINA CONECTA6009Adamantina62070503***6304ABCD`
      : null

    const payment = await prisma.payment.create({
      data: {
        amount,
        method,
        status: 'completed', // Simulated success
        clientId: session.user.id,
        serviceId,
        pixCode,
      },
    })

    // Notify provider about payment
    if (service.providerId) {
      const provider = await prisma.provider.findUnique({
        where: { id: service.providerId },
        select: { userId: true },
      })
      if (provider) {
        await prisma.notification.create({
          data: {
            userId: provider.userId,
            message: `Pagamento de R$ ${amount.toFixed(2)} recebido via ${method.toUpperCase()}!`,
            type: 'success',
          },
        })
      }
    }

    return NextResponse.json(payment, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao processar pagamento.' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const payments = await prisma.payment.findMany({
      where: { clientId: session.user.id },
      orderBy: { createdAt: 'desc' },
      include: { service: { include: { category: true } } },
    })
    return NextResponse.json(payments)
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao buscar pagamentos.' }, { status: 500 })
  }
}
