import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { serviceRequestSchema } from '@/lib/validations'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const isProvider = session.user.role === 'provider'

  try {
    let where: any = {}

    if (session.user.role === 'admin') {
      if (status) where.status = status
    } else if (isProvider) {
      const provider = await prisma.provider.findUnique({ where: { userId: session.user.id } })
      if (provider) where.providerId = provider.id
      if (status) where.status = status
    } else {
      where.clientId = session.user.id
      if (status) where.status = status
    }

    const requests = await prisma.serviceRequest.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        category: true,
        client: { select: { id: true, name: true, phone: true } },
        provider: { include: { user: { select: { id: true, name: true, phone: true } } } },
        payments: { select: { status: true, method: true } },
      },
    })

    return NextResponse.json(requests)
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao buscar solicitações.' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const body = await req.json()
    const parsed = serviceRequestSchema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0].message },
        { status: 400 }
      )
    }

    const { title, description, categoryId, location, price, scheduledAt } = parsed.data
    const { providerId } = body

    const request = await prisma.serviceRequest.create({
      data: {
        title,
        description,
        categoryId,
        location,
        price: price ?? null,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        clientId: session.user.id,
        providerId: providerId || null,
        status: providerId ? 'assigned' : 'open',
      },
    })

    // Notify provider if assigned
    if (providerId) {
      const provider = await prisma.provider.findUnique({
        where: { id: providerId },
        select: { userId: true },
      })
      if (provider) {
        await prisma.notification.create({
          data: {
            userId: provider.userId,
            message: `Nova solicitação recebida: "${title}"`,
            type: 'info',
          },
        })
      }
    }

    return NextResponse.json(request, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao criar solicitação.' }, { status: 500 })
  }
}
