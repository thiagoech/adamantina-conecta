import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

export async function GET(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  const request = await prisma.serviceRequest.findUnique({
    where: { id: params.id },
    include: {
      category: true,
      client: true,
      provider: { include: { user: true } },
      reviews: { include: { client: true } },
      payments: true,
    },
  })

  if (!request) return NextResponse.json({ error: 'Solicitação não encontrada.' }, { status: 404 })

  return NextResponse.json(request)
}

export async function PATCH(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  const request = await prisma.serviceRequest.findUnique({ where: { id: params.id } })
  if (!request) return NextResponse.json({ error: 'Solicitação não encontrada.' }, { status: 404 })

  // Check access
  const isClient = request.clientId === session.user.id
  const isAdmin = session.user.role === 'admin'
  let isProvider = false

  if (request.providerId) {
    const provider = await prisma.provider.findUnique({ where: { userId: session.user.id } })
    isProvider = provider?.id === request.providerId
  }

  if (!isClient && !isProvider && !isAdmin) {
    return NextResponse.json({ error: 'Sem permissão.' }, { status: 403 })
  }

  const body = await req.json()
  const { status, price, providerId, scheduledAt } = body

  // Validate status transitions
  const allowedTransitions: Record<string, string[]> = {
    open: ['assigned', 'in_progress', 'cancelled'],
    assigned: ['in_progress', 'cancelled'],
    in_progress: ['completed', 'cancelled'],
    completed: [],
    cancelled: [],
  }

  if (status && !isAdmin) {
    const allowed = allowedTransitions[request.status] || []
    if (!allowed.includes(status)) {
      return NextResponse.json(
        { error: `Transição de '${request.status}' para '${status}' não permitida.` },
        { status: 400 }
      )
    }
  }

  try {
    const updated = await prisma.serviceRequest.update({
      where: { id: params.id },
      data: {
        ...(status && { status }),
        ...(price !== undefined && { price }),
        ...(providerId !== undefined && { providerId }),
        ...(scheduledAt !== undefined && { scheduledAt: scheduledAt ? new Date(scheduledAt) : null }),
      },
    })

    // Send notifications on status change
    if (status === 'completed') {
      await prisma.notification.create({
        data: {
          userId: request.clientId,
          message: `Seu serviço "${request.title}" foi concluído! Avalie o prestador.`,
          type: 'success',
        },
      })
    } else if (status === 'in_progress') {
      await prisma.notification.create({
        data: {
          userId: request.clientId,
          message: `O prestador iniciou o serviço "${request.title}".`,
          type: 'info',
        },
      })
    } else if (status === 'cancelled') {
      if (request.providerId) {
        const provider = await prisma.provider.findUnique({
          where: { id: request.providerId },
          select: { userId: true },
        })
        if (provider) {
          await prisma.notification.create({
            data: {
              userId: provider.userId,
              message: `A solicitação "${request.title}" foi cancelada.`,
              type: 'info',
            },
          })
        }
      }
    }

    return NextResponse.json(updated)
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao atualizar solicitação.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'admin') {
    return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })
  }

  try {
    await prisma.serviceRequest.delete({ where: { id: params.id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao deletar.' }, { status: 500 })
  }
}
