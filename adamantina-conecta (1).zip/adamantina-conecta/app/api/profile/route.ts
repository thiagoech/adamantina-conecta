import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        provider: true,
        subscription: true,
      },
    })

    if (!user) return NextResponse.json({ error: 'Usuário não encontrado.' }, { status: 404 })

    // Remove password from response
    const { password, ...safeUser } = user
    return NextResponse.json(safeUser)
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao buscar perfil.' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const body = await req.json()
    const { name, phone, address, bio, skills, available } = body

    // Update user
    const user = await prisma.user.update({
      where: { id: session.user.id },
      data: {
        ...(name && { name }),
        ...(phone !== undefined && { phone }),
        ...(address !== undefined && { address }),
      },
    })

    // Update provider profile if applicable
    if (session.user.role === 'provider') {
      const existingProvider = await prisma.provider.findUnique({
        where: { userId: session.user.id },
      })

      if (existingProvider) {
        await prisma.provider.update({
          where: { userId: session.user.id },
          data: {
            ...(bio !== undefined && { bio }),
            ...(skills !== undefined && { skills }),
            ...(available !== undefined && { available }),
          },
        })
      } else {
        await prisma.provider.create({
          data: {
            userId: session.user.id,
            bio: bio || null,
            skills: skills || [],
            available: available ?? true,
          },
        })
      }
    }

    const { password, ...safeUser } = user
    return NextResponse.json(safeUser)
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao atualizar perfil.' }, { status: 500 })
  }
}
