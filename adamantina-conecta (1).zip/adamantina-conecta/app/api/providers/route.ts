import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const categoryId = searchParams.get('category')
  const q = searchParams.get('q')

  try {
    const providers = await prisma.provider.findMany({
      where: {
        verified: true,
        ...(q && {
          OR: [
            { user: { name: { contains: q, mode: 'insensitive' } } },
            { bio: { contains: q, mode: 'insensitive' } },
            { skills: { has: q } },
          ],
        }),
      },
      include: {
        user: { select: { id: true, name: true, phone: true, city: true } },
      },
      orderBy: [{ premium: 'desc' }, { rating: 'desc' }],
    })

    return NextResponse.json(providers)
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao buscar prestadores.' }, { status: 500 })
  }
}
