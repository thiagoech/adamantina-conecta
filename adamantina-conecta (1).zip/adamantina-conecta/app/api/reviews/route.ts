import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { reviewSchema } from '@/lib/validations'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })

  try {
    const body = await req.json()
    const parsed = reviewSchema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 })
    }

    const { rating, comment, serviceId, providerId } = parsed.data

    // Verify service belongs to this client and is completed
    const service = await prisma.serviceRequest.findUnique({
      where: { id: serviceId },
    })

    if (!service) {
      return NextResponse.json({ error: 'Serviço não encontrado.' }, { status: 404 })
    }

    if (service.clientId !== session.user.id) {
      return NextResponse.json({ error: 'Sem permissão.' }, { status: 403 })
    }

    if (service.status !== 'completed') {
      return NextResponse.json({ error: 'O serviço precisa estar concluído para ser avaliado.' }, { status: 400 })
    }

    // Check if already reviewed
    const existing = await prisma.review.findFirst({
      where: { serviceId, clientId: session.user.id },
    })
    if (existing) {
      return NextResponse.json({ error: 'Você já avaliou este serviço.' }, { status: 400 })
    }

    // Create review
    const review = await prisma.review.create({
      data: {
        rating,
        comment,
        clientId: session.user.id,
        providerId,
        serviceId,
      },
    })

    // Recalculate provider's average rating
    const allReviews = await prisma.review.aggregate({
      where: { providerId },
      _avg: { rating: true },
      _count: { rating: true },
    })

    await prisma.provider.update({
      where: { id: providerId },
      data: {
        rating: allReviews._avg.rating || 0,
        totalReviews: allReviews._count.rating,
      },
    })

    // Notify provider
    const provider = await prisma.provider.findUnique({
      where: { id: providerId },
      select: { userId: true },
    })
    if (provider) {
      await prisma.notification.create({
        data: {
          userId: provider.userId,
          message: `Você recebeu uma avaliação de ${rating} estrelas!`,
          type: 'success',
        },
      })
    }

    return NextResponse.json(review, { status: 201 })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao criar avaliação.' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const providerId = searchParams.get('providerId')

  try {
    const reviews = await prisma.review.findMany({
      where: providerId ? { providerId } : {},
      orderBy: { createdAt: 'desc' },
      include: { client: { select: { name: true } } },
    })
    return NextResponse.json(reviews)
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao buscar avaliações.' }, { status: 500 })
  }
}
