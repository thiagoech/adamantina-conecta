import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'admin') {
    return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })
  }

  try {
    const [
      totalUsers,
      totalProviders,
      verifiedProviders,
      totalRequests,
      openRequests,
      completedRequests,
      totalRevenue,
      statusBreakdown,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.provider.count(),
      prisma.provider.count({ where: { verified: true } }),
      prisma.serviceRequest.count(),
      prisma.serviceRequest.count({ where: { status: 'open' } }),
      prisma.serviceRequest.count({ where: { status: 'completed' } }),
      prisma.payment.aggregate({ where: { status: 'completed' }, _sum: { amount: true } }),
      prisma.serviceRequest.groupBy({ by: ['status'], _count: { status: true } }),
    ])

    return NextResponse.json({
      totalUsers,
      totalProviders,
      verifiedProviders,
      totalRequests,
      openRequests,
      completedRequests,
      totalRevenue: totalRevenue._sum.amount || 0,
      statusBreakdown,
    })
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao buscar estatísticas.' }, { status: 500 })
  }
}
