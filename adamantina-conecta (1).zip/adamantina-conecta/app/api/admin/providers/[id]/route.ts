import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

interface Params { params: { id: string } }

export async function PATCH(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'admin') {
    return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { verified, premium, available } = body

    const provider = await prisma.provider.update({
      where: { id: params.id },
      data: {
        ...(verified !== undefined && { verified }),
        ...(premium !== undefined && { premium }),
        ...(available !== undefined && { available }),
      },
      include: { user: true },
    })

    // Notify provider
    const message = verified !== undefined
      ? verified
        ? 'Seu perfil foi verificado pelo admin! ✓'
        : 'Sua verificação foi removida.'
      : premium !== undefined
        ? premium
          ? 'Você agora tem conta Premium! ⭐'
          : 'Seu status premium foi removido.'
        : 'Seu perfil foi atualizado.'

    await prisma.notification.create({
      data: {
        userId: provider.user.id,
        message,
        type: verified || premium ? 'success' : 'info',
      },
    })

    return NextResponse.json(provider)
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: 'Erro ao atualizar prestador.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'admin') {
    return NextResponse.json({ error: 'Não autorizado.' }, { status: 401 })
  }

  try {
    await prisma.provider.delete({ where: { id: params.id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Erro ao deletar.' }, { status: 500 })
  }
}
