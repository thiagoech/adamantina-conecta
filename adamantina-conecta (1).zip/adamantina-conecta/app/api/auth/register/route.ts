import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { registerSchema } from '@/lib/validations'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = registerSchema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0].message },
        { status: 400 }
      )
    }

    const { name, email, password, role, phone } = parsed.data
    const hashedPassword = await bcrypt.hash(password, 10)

    const user = await prisma.user.create({
      data: { name, email, password: hashedPassword, role, phone },
    })

    // If provider, create provider profile
    if (role === 'provider') {
      await prisma.provider.create({
        data: { userId: user.id },
      })
    }

    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name } }, { status: 201 })
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'Este e-mail já está em uso.' }, { status: 400 })
    }
    console.error(error)
    return NextResponse.json({ error: 'Erro interno do servidor.' }, { status: 500 })
  }
}
