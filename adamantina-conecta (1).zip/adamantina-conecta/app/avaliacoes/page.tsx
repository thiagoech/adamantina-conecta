import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StarRating from '@/components/ui/StarRating'

export default async function AvaliacoesPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const isProvider = session.user.role === 'provider'

  if (!isProvider) redirect('/dashboard')

  const provider = await prisma.provider.findUnique({
    where: { userId: session.user.id },
    include: {
      reviews: {
        include: {
          client: true,
          service: { include: { category: true } },
        },
        orderBy: { createdAt: 'desc' },
      },
    },
  })

  if (!provider) redirect('/dashboard')

  const ratingBreakdown = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: provider.reviews.filter(r => r.rating === star).length,
  }))

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">Minhas Avaliações</h1>

        {/* Summary */}
        <div className="card p-6 mb-6">
          <div className="flex items-center gap-8 flex-wrap">
            <div className="text-center">
              <p className="text-6xl font-extrabold text-gray-900">{provider.rating.toFixed(1)}</p>
              <StarRating value={Math.round(provider.rating)} readonly size="md" />
              <p className="text-sm text-gray-400 mt-1">{provider.totalReviews} avaliações</p>
            </div>
            <div className="flex-1 min-w-[200px] space-y-2">
              {ratingBreakdown.map(({ star, count }) => (
                <div key={star} className="flex items-center gap-3">
                  <span className="text-sm text-gray-500 w-8">{star} ★</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-yellow-400 h-2 rounded-full transition-all"
                      style={{ width: provider.totalReviews > 0 ? `${(count / provider.totalReviews) * 100}%` : '0%' }}
                    />
                  </div>
                  <span className="text-sm text-gray-500 w-6 text-right">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Review list */}
        {provider.reviews.length === 0 ? (
          <div className="card p-16 text-center">
            <span className="text-5xl block mb-3">⭐</span>
            <h3 className="text-lg font-semibold text-gray-700">Nenhuma avaliação ainda</h3>
            <p className="text-gray-400 text-sm mt-1">Complete serviços para receber avaliações dos clientes.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {provider.reviews.map((review) => (
              <div key={review.id} className="card p-5">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center text-sky-700 font-bold shrink-0">
                    {review.client.name?.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <span className="font-semibold text-gray-900">{review.client.name}</span>
                        <span className="text-gray-400 text-sm ml-2">· {review.service.category.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex">
                          {[1,2,3,4,5].map(s => (
                            <span key={s} className={`text-base ${s <= review.rating ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                          ))}
                        </div>
                        <span className="text-xs text-gray-400">
                          {new Date(review.createdAt).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                    </div>
                    {review.comment ? (
                      <p className="text-gray-600 mt-2 leading-relaxed">{review.comment}</p>
                    ) : (
                      <p className="text-gray-400 text-sm mt-2 italic">Sem comentário.</p>
                    )}
                    <p className="text-xs text-gray-400 mt-2">Serviço: {review.service.title}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
