'use client'
import { useEffect } from 'react'

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="text-center">
        <span className="text-6xl block mb-4">⚠️</span>
        <h2 className="text-2xl font-bold text-gray-900">Algo deu errado</h2>
        <p className="text-gray-500 mt-2 mb-6">{error.message || 'Ocorreu um erro inesperado.'}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={reset} className="btn-primary px-6 py-2.5">Tentar novamente</button>
          <a href="/home" className="btn-secondary px-6 py-2.5">Voltar ao início</a>
        </div>
      </div>
    </div>
  )
}
