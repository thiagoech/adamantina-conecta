'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Modal from '@/components/ui/Modal'
import StarRating from '@/components/ui/StarRating'
import Toast from '@/components/ui/Toast'

interface Props {
  request: {
    id: string
    status: string
    price: number | null
    clientId: string
    providerId: string | null
  }
  sessionUserId: string
  sessionUserRole: string
  isProvider: boolean
  hasReview: boolean
  hasPayment: boolean
  providerUserId?: string
}

export default function RequestActions({
  request, sessionUserId, sessionUserRole, isProvider, hasReview, hasPayment, providerUserId
}: Props) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [showPayModal, setShowPayModal] = useState(false)
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [payMethod, setPayMethod] = useState<'pix' | 'card'>('pix')
  const [review, setReview] = useState({ rating: 5, comment: '' })

  const isClient = request.clientId === sessionUserId
  const isAdmin = sessionUserRole === 'admin'

  const updateStatus = async (status: string) => {
    setLoading(true)
    const res = await fetch(`/api/requests/${request.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    setLoading(false)
    if (res.ok) {
      setToast({ message: `Status atualizado para: ${status}`, type: 'success' })
      router.refresh()
    } else {
      setToast({ message: 'Erro ao atualizar status', type: 'error' })
    }
  }

  const handlePayment = async () => {
    setLoading(true)
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ serviceId: request.id, method: payMethod, amount: request.price }),
    })
    setLoading(false)
    setShowPayModal(false)
    if (res.ok) {
      setToast({ message: 'Pagamento realizado com sucesso!', type: 'success' })
      router.refresh()
    } else {
      setToast({ message: 'Erro ao processar pagamento', type: 'error' })
    }
  }

  const handleReview = async () => {
    if (!request.providerId) return
    setLoading(true)
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        rating: review.rating,
        comment: review.comment,
        serviceId: request.id,
        providerId: request.providerId,
      }),
    })
    setLoading(false)
    setShowReviewModal(false)
    if (res.ok) {
      setToast({ message: 'Avaliação enviada! Obrigado.', type: 'success' })
      router.refresh()
    } else {
      const data = await res.json()
      setToast({ message: data.error || 'Erro ao enviar avaliação', type: 'error' })
    }
  }

  return (
    <>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div className="card p-5 space-y-3">
        <h3 className="text-sm font-semibold text-gray-700">Ações</h3>

        {/* Provider actions */}
        {isProvider && (
          <>
            {request.status === 'open' && (
              <button onClick={() => updateStatus('in_progress')} disabled={loading}
                className="btn-primary w-full py-2.5 disabled:opacity-50">
                Aceitar e Iniciar
              </button>
            )}
            {request.status === 'in_progress' && (
              <button onClick={() => updateStatus('completed')} disabled={loading}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-lg w-full transition-colors disabled:opacity-50">
                Marcar como Concluído
              </button>
            )}
          </>
        )}

        {/* Client actions */}
        {isClient && (
          <>
            {request.status === 'completed' && request.price && !hasPayment && (
              <button onClick={() => setShowPayModal(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-lg w-full transition-colors">
                💳 Pagar R$ {request.price.toFixed(2)}
              </button>
            )}
            {request.status === 'completed' && hasPayment && !hasReview && request.providerId && (
              <button onClick={() => setShowReviewModal(true)}
                className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-2.5 rounded-lg w-full transition-colors">
                ⭐ Avaliar Prestador
              </button>
            )}
            {(request.status === 'open' || request.status === 'assigned') && (
              <button onClick={() => updateStatus('cancelled')} disabled={loading}
                className="btn-danger w-full py-2.5 disabled:opacity-50">
                Cancelar Solicitação
              </button>
            )}
          </>
        )}

        {/* Admin actions */}
        {isAdmin && (
          <div className="space-y-2 pt-2 border-t border-gray-100">
            <p className="text-xs text-gray-400 font-medium">Admin</p>
            {['open', 'assigned', 'in_progress', 'completed', 'cancelled'].map((s) => (
              <button key={s} onClick={() => updateStatus(s)} disabled={loading || request.status === s}
                className="w-full text-left text-xs px-3 py-2 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed text-gray-600 border border-gray-100">
                → Mudar para: {s}
              </button>
            ))}
          </div>
        )}

        {!isProvider && !isClient && !isAdmin && (
          <p className="text-gray-400 text-sm text-center py-2">Sem ações disponíveis</p>
        )}
      </div>

      {/* Payment Modal */}
      <Modal isOpen={showPayModal} onClose={() => setShowPayModal(false)} title="Realizar Pagamento">
        <div className="space-y-5">
          <div className="bg-gray-50 rounded-xl p-4 text-center">
            <p className="text-gray-500 text-sm">Valor a pagar</p>
            <p className="text-4xl font-extrabold text-gray-900 mt-1">R$ {request.price?.toFixed(2)}</p>
          </div>

          <div>
            <p className="label">Forma de pagamento</p>
            <div className="grid grid-cols-2 gap-3 mt-2">
              {(['pix', 'card'] as const).map((m) => (
                <button key={m} type="button" onClick={() => setPayMethod(m)}
                  className={`p-4 rounded-xl border-2 text-center transition-all ${
                    payMethod === m ? 'border-sky-500 bg-sky-50' : 'border-gray-200 hover:border-gray-300'
                  }`}>
                  <span className="text-2xl block mb-1">{m === 'pix' ? '⚡' : '💳'}</span>
                  <span className="font-medium text-sm">{m === 'pix' ? 'PIX' : 'Cartão'}</span>
                </button>
              ))}
            </div>
          </div>

          {payMethod === 'pix' && (
            <div className="bg-sky-50 border border-sky-200 rounded-xl p-4 text-sm text-sky-800">
              <p className="font-semibold mb-1">⚡ Pagamento via PIX</p>
              <p>Código PIX: <span className="font-mono text-xs bg-white px-2 py-0.5 rounded border border-sky-200">adamantina@conecta.pix</span></p>
              <p className="text-xs mt-2 text-sky-600">* Simulado — Em produção integre com Mercado Pago</p>
            </div>
          )}

          {payMethod === 'card' && (
            <div className="space-y-3">
              <input type="text" className="input" placeholder="Número do cartão" maxLength={19} />
              <div className="grid grid-cols-2 gap-3">
                <input type="text" className="input" placeholder="MM/AA" maxLength={5} />
                <input type="text" className="input" placeholder="CVV" maxLength={3} />
              </div>
              <p className="text-xs text-gray-400">* Simulado — Em produção integre com Stripe</p>
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={() => setShowPayModal(false)} className="btn-secondary flex-1 py-3">Cancelar</button>
            <button onClick={handlePayment} disabled={loading} className="btn-primary flex-1 py-3 disabled:opacity-50">
              {loading ? 'Processando...' : 'Confirmar Pagamento'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Review Modal */}
      <Modal isOpen={showReviewModal} onClose={() => setShowReviewModal(false)} title="Avaliar Prestador">
        <div className="space-y-5">
          <div className="text-center">
            <p className="text-gray-600 mb-3">Como foi o serviço?</p>
            <div className="flex justify-center">
              <StarRating value={review.rating} onChange={(v) => setReview({ ...review, rating: v })} size="lg" />
            </div>
            <p className="text-gray-400 text-sm mt-2">{review.rating}/5 estrelas</p>
          </div>

          <div>
            <label className="label">Comentário (opcional)</label>
            <textarea
              className="input min-h-[100px] resize-none"
              placeholder="Descreva sua experiência com o prestador..."
              value={review.comment}
              onChange={(e) => setReview({ ...review, comment: e.target.value })}
            />
          </div>

          <div className="flex gap-3">
            <button onClick={() => setShowReviewModal(false)} className="btn-secondary flex-1 py-3">Cancelar</button>
            <button onClick={handleReview} disabled={loading} className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-3 rounded-lg flex-1 transition-colors disabled:opacity-50">
              {loading ? 'Enviando...' : '⭐ Enviar Avaliação'}
            </button>
          </div>
        </div>
      </Modal>
    </>
  )
}
