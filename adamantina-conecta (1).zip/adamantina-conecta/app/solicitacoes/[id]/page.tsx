import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect, notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StatusBadge from '@/components/ui/StatusBadge'
import RequestActions from './RequestActions'
import Link from 'next/link'

interface Props {
  params: { id: string }
}

export default async function RequestDetailPage({ params }: Props) {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const request = await prisma.serviceRequest.findUnique({
    where: { id: params.id },
    include: {
      category: true,
      client: true,
      provider: { include: { user: true } },
      reviews: { include: { client: true } },
      payments: true,
    },
  })

  if (!request) notFound()

  // Access control
  const isClient = request.clientId === session.user.id
  const provider = request.provider
    ? await prisma.provider.findUnique({ where: { userId: session.user.id } })
    : null
  const isProvider = provider?.id === request.providerId
  const isAdmin = session.user.role === 'admin'

  if (!isClient && !isProvider && !isAdmin) redirect('/dashboard')

  const hasReview = request.reviews.some(r => r.clientId === session.user.id)
  const payment = request.payments.find(p => p.status === 'completed')

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/solicitacoes" className="text-sky-600 text-sm hover:underline">← Voltar às solicitações</Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main */}
          <div className="lg:col-span-2 space-y-5">
            <div className="card p-6">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-3 flex-wrap mb-1">
                    <h1 className="text-xl font-bold text-gray-900">{request.title}</h1>
                    <StatusBadge status={request.status} />
                  </div>
                  <p className="text-sm text-gray-400">{request.category.icon} {request.category.name}</p>
                </div>
                {request.price && (
                  <div className="text-right shrink-0">
                    <p className="text-2xl font-extrabold text-gray-900">R$ {request.price.toFixed(2)}</p>
                    {payment && <span className="text-xs text-green-600 font-medium">✓ Pago via {payment.method.toUpperCase()}</span>}
                  </div>
                )}
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">Descrição</h3>
                <p className="text-gray-600 leading-relaxed">{request.description}</p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Local</span>
                  <p className="text-gray-700 mt-0.5">📍 {request.location}</p>
                </div>
                {request.scheduledAt && (
                  <div>
                    <span className="text-gray-400">Data agendada</span>
                    <p className="text-gray-700 mt-0.5">📅 {new Date(request.scheduledAt).toLocaleDateString('pt-BR', { dateStyle: 'long' })}</p>
                  </div>
                )}
                <div>
                  <span className="text-gray-400">Criado em</span>
                  <p className="text-gray-700 mt-0.5">{new Date(request.createdAt).toLocaleDateString('pt-BR')}</p>
                </div>
              </div>
            </div>

            {/* Reviews */}
            {request.reviews.length > 0 && (
              <div className="card p-6">
                <h2 className="font-bold text-gray-900 mb-4">Avaliações</h2>
                {request.reviews.map((rev) => (
                  <div key={rev.id} className="flex gap-3">
                    <div className="w-9 h-9 bg-sky-100 rounded-full flex items-center justify-center font-bold text-sky-700 text-sm shrink-0">
                      {rev.client.name?.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{rev.client.name}</span>
                        <div className="flex">{[1,2,3,4,5].map(s => (
                          <span key={s} className={`text-xs ${s <= rev.rating ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                        ))}</div>
                      </div>
                      {rev.comment && <p className="text-gray-600 text-sm mt-1">{rev.comment}</p>}
                      <p className="text-xs text-gray-400 mt-0.5">{new Date(rev.createdAt).toLocaleDateString('pt-BR')}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            {/* Client */}
            <div className="card p-5">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Cliente</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center font-bold text-sky-700">
                  {request.client.name?.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{request.client.name}</p>
                  {request.client.phone && <p className="text-xs text-gray-400">{request.client.phone}</p>}
                </div>
              </div>
            </div>

            {/* Provider */}
            {request.provider ? (
              <div className="card p-5">
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Prestador</h3>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center font-bold text-emerald-700">
                    {request.provider.user.name?.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{request.provider.user.name}</p>
                    {request.provider.user.phone && <p className="text-xs text-gray-400">{request.provider.user.phone}</p>}
                  </div>
                </div>
                <Link href={`/servicos/${request.providerId}`} className="text-sky-600 text-xs hover:underline mt-2 inline-block">
                  Ver perfil do prestador →
                </Link>
              </div>
            ) : (
              <div className="card p-5 text-center">
                <span className="text-3xl block mb-2">🔍</span>
                <p className="text-sm text-gray-500">Aguardando prestador</p>
                <Link href="/catalogo" className="text-sky-600 text-xs hover:underline mt-1 inline-block">Encontrar prestador</Link>
              </div>
            )}

            {/* Actions */}
            <RequestActions
              request={{
                id: request.id,
                status: request.status,
                price: request.price,
                clientId: request.clientId,
                providerId: request.providerId,
              }}
              sessionUserId={session.user.id}
              sessionUserRole={session.user.role}
              isProvider={isProvider}
              hasReview={hasReview}
              hasPayment={!!payment}
              providerUserId={request.provider?.userId}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
