'use client'
import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import Navbar from '@/components/layout/Navbar'
import Toast from '@/components/ui/Toast'

interface Category {
  id: string
  name: string
  icon: string
}

export default function NovaSolicitacaoPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [form, setForm] = useState({
    title: '',
    description: '',
    categoryId: '',
    location: 'Adamantina-SP',
    price: '',
    scheduledAt: '',
    providerId: searchParams.get('provider') || '',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
    fetch('/api/services/categories').then(r => r.json()).then(setCategories)
  }, [status, router])

  const validate = () => {
    const e: Record<string, string> = {}
    if (form.title.length < 5) e.title = 'Título deve ter pelo menos 5 caracteres'
    if (form.description.length < 20) e.description = 'Descrição deve ter pelo menos 20 caracteres'
    if (!form.categoryId) e.categoryId = 'Selecione uma categoria'
    if (form.location.length < 5) e.location = 'Informe o endereço completo'
    return e
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const v = validate()
    setErrors(v)
    if (Object.keys(v).length > 0) return

    setLoading(true)
    const res = await fetch('/api/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        price: form.price ? parseFloat(form.price) : undefined,
      }),
    })
    setLoading(false)

    if (res.ok) {
      const data = await res.json()
      setToast({ message: 'Solicitação criada com sucesso!', type: 'success' })
      setTimeout(() => router.push(`/solicitacoes/${data.id}`), 1500)
    } else {
      const data = await res.json()
      setToast({ message: data.error || 'Erro ao criar solicitação', type: 'error' })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Nova Solicitação</h1>
          <p className="text-gray-500 mt-1">Descreva o serviço que você precisa</p>
        </div>

        <div className="card p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label">Categoria *</label>
              <select
                className="input"
                value={form.categoryId}
                onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
              >
                <option value="">Selecione uma categoria...</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
                ))}
              </select>
              {errors.categoryId && <p className="text-red-500 text-xs mt-1">{errors.categoryId}</p>}
            </div>

            <div>
              <label className="label">Título do serviço *</label>
              <input
                type="text"
                className="input"
                placeholder="Ex: Limpeza completa da casa, 3 quartos"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
              {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
            </div>

            <div>
              <label className="label">Descrição detalhada *</label>
              <textarea
                className="input min-h-[120px] resize-none"
                placeholder="Descreva com detalhes o que precisa ser feito, condições do local, materiais necessários, etc."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
              <p className="text-xs text-gray-400 mt-1">{form.description.length} / 20 mínimo</p>
              {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
            </div>

            <div>
              <label className="label">Endereço / Local *</label>
              <input
                type="text"
                className="input"
                placeholder="Rua, número, bairro - Adamantina-SP"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
              />
              {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Orçamento (R$) <span className="text-gray-400 font-normal">opcional</span></label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  placeholder="Ex: 150.00"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                />
              </div>
              <div>
                <label className="label">Data desejada <span className="text-gray-400 font-normal">opcional</span></label>
                <input
                  type="datetime-local"
                  className="input"
                  value={form.scheduledAt}
                  onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })}
                />
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => router.back()} className="btn-secondary flex-1 py-3">
                Cancelar
              </button>
              <button type="submit" disabled={loading} className="btn-primary flex-1 py-3 disabled:opacity-50">
                {loading ? 'Criando...' : 'Criar Solicitação'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
