import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StatusBadge from '@/components/ui/StatusBadge'
import Link from 'next/link'

export default async function SolicitacoesPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const isProvider = session.user.role === 'provider'
  const provider = isProvider ? await prisma.provider.findUnique({ where: { userId: session.user.id } }) : null

  const requests = await prisma.serviceRequest.findMany({
    where: isProvider && provider
      ? { providerId: provider.id }
      : { clientId: session.user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      category: true,
      client: true,
      provider: { include: { user: true } },
      payments: true,
    },
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isProvider ? 'Solicitações Recebidas' : 'Minhas Solicitações'}
            </h1>
            <p className="text-gray-500 mt-1">{requests.length} solicitações encontradas</p>
          </div>
          {!isProvider && (
            <Link href="/solicitacoes/nova" className="btn-primary">+ Nova</Link>
          )}
        </div>

        {requests.length === 0 ? (
          <div className="card p-16 text-center">
            <span className="text-5xl block mb-3">📭</span>
            <h3 className="text-lg font-semibold text-gray-700">Nenhuma solicitação</h3>
            <p className="text-gray-400 text-sm mt-1">
              {isProvider ? 'Você ainda não recebeu solicitações.' : 'Você ainda não criou nenhuma solicitação.'}
            </p>
            {!isProvider && (
              <Link href="/solicitacoes/nova" className="btn-primary mt-4 inline-block">Criar primeira solicitação</Link>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((req) => (
              <Link key={req.id} href={`/solicitacoes/${req.id}`}
                className="card p-5 block hover:shadow-md hover:border-sky-200 transition-all">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-bold text-gray-900">{req.title}</h3>
                      <StatusBadge status={req.status} />
                    </div>
                    <p className="text-gray-500 text-sm line-clamp-2">{req.description}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 flex-wrap">
                      <span>📁 {req.category.name}</span>
                      <span>📍 {req.location}</span>
                      {isProvider ? (
                        <span>👤 {req.client.name}</span>
                      ) : req.provider ? (
                        <span>🔧 {req.provider.user.name}</span>
                      ) : (
                        <span className="text-orange-500">Aguardando prestador</span>
                      )}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    {req.price ? (
                      <p className="font-bold text-gray-900">R$ {req.price.toFixed(2)}</p>
                    ) : (
                      <p className="text-gray-400 text-sm">Sem valor</p>
                    )}
                    <p className="text-xs text-gray-400 mt-0.5">{new Date(req.createdAt).toLocaleDateString('pt-BR')}</p>
                    {req.payments.some(p => p.status === 'completed') && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium mt-1 inline-block">Pago ✓</span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
