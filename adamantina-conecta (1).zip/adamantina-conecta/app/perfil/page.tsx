'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/layout/Navbar'
import Toast from '@/components/ui/Toast'

export default function PerfilPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    city: '',
    bio: '',
    skills: '',
    available: true,
  })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
    if (status === 'authenticated') {
      fetch('/api/profile').then(r => r.json()).then((data) => {
        setForm({
          name: data.name || '',
          phone: data.phone || '',
          address: data.address || '',
          city: data.city || 'Adamantina-SP',
          bio: data.provider?.bio || '',
          skills: (data.provider?.skills || []).join(', '),
          available: data.provider?.available ?? true,
        })
        setLoading(false)
      })
    }
  }, [status, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    const res = await fetch('/api/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: form.name,
        phone: form.phone,
        address: form.address,
        bio: form.bio,
        skills: form.skills ? form.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
        available: form.available,
      }),
    })
    setSaving(false)
    if (res.ok) {
      setToast({ message: 'Perfil atualizado com sucesso!', type: 'success' })
    } else {
      setToast({ message: 'Erro ao atualizar perfil.', type: 'error' })
    }
  }

  if (loading) return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex items-center justify-center py-32">
        <div className="w-8 h-8 border-4 border-sky-200 border-t-sky-600 rounded-full animate-spin" />
      </div>
    </div>
  )

  const isProvider = session?.user.role === 'provider'

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">Meu Perfil</h1>

        {/* Avatar */}
        <div className="card p-6 mb-6 flex items-center gap-5">
          <div className="w-20 h-20 bg-gradient-to-br from-sky-400 to-sky-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
            {form.name?.charAt(0)?.toUpperCase()}
          </div>
          <div>
            <p className="font-bold text-gray-900 text-lg">{form.name}</p>
            <p className="text-gray-500 text-sm">{session?.user.email}</p>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block ${
              isProvider ? 'bg-emerald-100 text-emerald-700' : 'bg-sky-100 text-sky-700'
            }`}>
              {isProvider ? '🔧 Prestador' : '👤 Cliente'}
            </span>
          </div>
        </div>

        <div className="card p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label">Nome completo</label>
              <input type="text" className="input" value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>

            <div>
              <label className="label">Telefone</label>
              <input type="tel" className="input" placeholder="(18) 99999-9999" value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>

            <div>
              <label className="label">Endereço</label>
              <input type="text" className="input" placeholder="Rua, número, bairro" value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>

            {isProvider && (
              <>
                <div className="border-t border-gray-100 pt-5">
                  <h3 className="font-semibold text-gray-800 mb-4">Informações do Prestador</h3>
                </div>

                <div>
                  <label className="label">Bio / Apresentação</label>
                  <textarea
                    className="input min-h-[100px] resize-none"
                    placeholder="Descreva sua experiência, especialidades e diferenciais..."
                    value={form.bio}
                    onChange={(e) => setForm({ ...form, bio: e.target.value })}
                  />
                </div>

                <div>
                  <label className="label">Habilidades <span className="text-gray-400 font-normal">(separadas por vírgula)</span></label>
                  <input type="text" className="input" placeholder="Limpeza, Organização, Faxina pesada"
                    value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} />
                  {form.skills && (
                    <div className="flex gap-1 flex-wrap mt-2">
                      {form.skills.split(',').map(s => s.trim()).filter(Boolean).map((skill) => (
                        <span key={skill} className="text-xs bg-sky-100 text-sky-700 px-2 py-1 rounded-full">{skill}</span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, available: !form.available })}
                    className={`relative w-12 h-6 rounded-full transition-colors ${form.available ? 'bg-emerald-500' : 'bg-gray-300'}`}
                  >
                    <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.available ? 'translate-x-6' : 'translate-x-0.5'}`} />
                  </button>
                  <span className="text-sm font-medium text-gray-700">
                    {form.available ? '✅ Disponível para novos serviços' : '⛔ Indisponível no momento'}
                  </span>
                </div>
              </>
            )}

            <button type="submit" disabled={saving} className="btn-primary w-full py-3 mt-2 disabled:opacity-50">
              {saving ? 'Salvando...' : 'Salvar alterações'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
