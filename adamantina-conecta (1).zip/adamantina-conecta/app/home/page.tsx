import Link from 'next/link'
import { prisma } from '@/lib/prisma'

export default async function HomePage() {
  const [categoryCount, providerCount, requestCount] = await Promise.all([
    prisma.serviceCategory.count(),
    prisma.provider.count({ where: { verified: true } }),
    prisma.serviceRequest.count({ where: { status: 'completed' } }),
  ])

  const categories = await prisma.serviceCategory.findMany({ take: 6 })

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <Link href="/home" className="flex items-center gap-2">
            <span className="text-2xl">🏙️</span>
            <span className="font-bold text-gray-900 text-xl">Adamantina <span className="text-sky-600">Conecta</span></span>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/catalogo" className="text-gray-600 hover:text-sky-600 font-medium hidden sm:block">Serviços</Link>
            <Link href="/login" className="text-gray-600 hover:text-sky-600 font-medium">Entrar</Link>
            <Link href="/cadastro" className="btn-primary text-sm">Cadastrar grátis</Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-sky-100 text-sky-700 text-sm font-medium px-4 py-1.5 rounded-full mb-6">
            <span>📍</span> Adamantina-SP e região
          </div>
          <h1 className="text-5xl sm:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
            Serviços locais,<br />
            <span className="text-sky-600">na sua porta</span>
          </h1>
          <p className="text-xl text-gray-500 mb-10">
            Conectamos você a prestadores de serviços confiáveis e verificados de Adamantina. Rápido, fácil e seguro.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/catalogo" className="btn-primary text-base px-8 py-3">
              Encontrar Serviços
            </Link>
            <Link href="/cadastro?role=provider" className="btn-secondary text-base px-8 py-3">
              Quero ser Prestador
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-3 gap-6 max-w-lg mx-auto text-center">
          <div className="card p-6">
            <div className="text-3xl font-extrabold text-sky-600">{categoryCount}</div>
            <div className="text-sm text-gray-500 mt-1">Categorias</div>
          </div>
          <div className="card p-6">
            <div className="text-3xl font-extrabold text-emerald-600">{providerCount}+</div>
            <div className="text-sm text-gray-500 mt-1">Prestadores</div>
          </div>
          <div className="card p-6">
            <div className="text-3xl font-extrabold text-purple-600">{requestCount}+</div>
            <div className="text-sm text-gray-500 mt-1">Serviços feitos</div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">O que você precisa?</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <Link key={cat.id} href={`/catalogo?category=${cat.id}`}
              className="card p-5 text-center hover:shadow-md hover:border-sky-200 transition-all group cursor-pointer">
              <div className="text-4xl mb-3 group-hover:scale-110 transition-transform inline-block">{cat.icon}</div>
              <p className="text-sm font-medium text-gray-700 group-hover:text-sky-600 leading-tight">{cat.name}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white border-y border-gray-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Como funciona</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '1', icon: '🔍', title: 'Descreva o serviço', desc: 'Diga o que precisa e quando quer ser atendido em Adamantina.' },
              { step: '2', icon: '🤝', title: 'Escolha o prestador', desc: 'Veja perfis, avaliações e escolha o melhor para você.' },
              { step: '3', icon: '✅', title: 'Contrate com segurança', desc: 'Pagamento pelo app, avalie o serviço ao concluir.' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-16 h-16 bg-sky-100 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">{item.icon}</div>
                <h3 className="font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Pronto para começar?</h2>
        <p className="text-gray-500 mb-8">Cadastro gratuito. Sem taxa de adesão.</p>
        <Link href="/cadastro" className="btn-primary text-base px-10 py-3">Criar conta grátis</Link>
      </section>

      <footer className="border-t border-gray-100 py-8 text-center text-sm text-gray-400">
        © 2024 Adamantina Conecta · Feito com ❤️ para Adamantina-SP
      </footer>
    </div>
  )
}
