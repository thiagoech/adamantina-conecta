import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'

interface Props {
  searchParams: { category?: string; q?: string }
}

export default async function CatalogoPage({ searchParams }: Props) {
  const categories = await prisma.serviceCategory.findMany()

  const providers = await prisma.provider.findMany({
    where: {
      verified: true,
      ...(searchParams.category ? {
        user: {
          serviceRequests: {
            some: { categoryId: searchParams.category }
          }
        }
      } : {}),
    },
    include: {
      user: true,
      reviews: { take: 3, orderBy: { createdAt: 'desc' } },
    },
    orderBy: [{ premium: 'desc' }, { rating: 'desc' }],
  })

  const selectedCategory = categories.find(c => c.id === searchParams.category)

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">
            {selectedCategory ? `${selectedCategory.icon} ${selectedCategory.name}` : 'Todos os Serviços'}
          </h1>
          <p className="text-gray-500 mt-1">Prestadores verificados em Adamantina-SP</p>
        </div>

        <div className="flex gap-8">
          {/* Sidebar */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="card p-4 sticky top-24">
              <h3 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">Categorias</h3>
              <nav className="space-y-1">
                <Link href="/catalogo"
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                    !searchParams.category ? 'bg-sky-50 text-sky-700 font-medium' : 'text-gray-600 hover:bg-gray-50'
                  }`}>
                  🗂️ Todas as categorias
                </Link>
                {categories.map((cat) => (
                  <Link key={cat.id} href={`/catalogo?category=${cat.id}`}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${
                      searchParams.category === cat.id ? 'bg-sky-50 text-sky-700 font-medium' : 'text-gray-600 hover:bg-gray-50'
                    }`}>
                    {cat.icon} {cat.name}
                  </Link>
                ))}
              </nav>
            </div>
          </aside>

          {/* Main */}
          <main className="flex-1">
            {/* Mobile categories */}
            <div className="lg:hidden flex gap-2 overflow-x-auto pb-3 mb-6 scrollbar-hide">
              <Link href="/catalogo"
                className={`shrink-0 px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                  !searchParams.category ? 'bg-sky-600 text-white border-sky-600' : 'bg-white text-gray-600 border-gray-200'
                }`}>
                Todas
              </Link>
              {categories.map((cat) => (
                <Link key={cat.id} href={`/catalogo?category=${cat.id}`}
                  className={`shrink-0 px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                    searchParams.category === cat.id ? 'bg-sky-600 text-white border-sky-600' : 'bg-white text-gray-600 border-gray-200'
                  }`}>
                  {cat.icon} {cat.name}
                </Link>
              ))}
            </div>

            {providers.length === 0 ? (
              <div className="card p-12 text-center">
                <span className="text-5xl mb-4 block">🔍</span>
                <h3 className="text-lg font-semibold text-gray-700">Nenhum prestador encontrado</h3>
                <p className="text-gray-500 text-sm mt-1">Tente outra categoria ou <Link href="/cadastro?role=provider" className="text-sky-600">seja o primeiro prestador nessa área!</Link></p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {providers.map((provider) => (
                  <Link key={provider.id} href={`/servicos/${provider.id}`}
                    className="card p-6 hover:shadow-md hover:border-sky-200 transition-all cursor-pointer group">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-sky-400 to-sky-600 rounded-full flex items-center justify-center text-white text-xl font-bold shrink-0">
                        {provider.user.name?.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold text-gray-900 group-hover:text-sky-600 transition-colors">{provider.user.name}</h3>
                          {provider.verified && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Verificado</span>}
                          {provider.premium && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-medium">⭐ Premium</span>}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex">
                            {[1,2,3,4,5].map(s => (
                              <span key={s} className={`text-sm ${s <= Math.round(provider.rating) ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                            ))}
                          </div>
                          <span className="text-sm text-gray-500">{provider.rating.toFixed(1)} ({provider.totalReviews} avaliações)</span>
                        </div>
                        {provider.bio && (
                          <p className="text-gray-500 text-sm mt-2 line-clamp-2">{provider.bio}</p>
                        )}
                        {provider.skills.length > 0 && (
                          <div className="flex gap-1 flex-wrap mt-3">
                            {provider.skills.slice(0, 3).map((skill) => (
                              <span key={skill} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">{skill}</span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  )
}
