import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="text-center">
        <p className="text-8xl font-extrabold text-sky-600">404</p>
        <h1 className="text-2xl font-bold text-gray-900 mt-4">Página não encontrada</h1>
        <p className="text-gray-500 mt-2">A página que você procura não existe.</p>
        <div className="flex gap-3 justify-center mt-8">
          <Link href="/home" className="btn-primary px-6 py-2.5">Ir para Home</Link>
          <Link href="/dashboard" className="btn-secondary px-6 py-2.5">Meu Dashboard</Link>
        </div>
      </div>
    </div>
  )
}
