import { prisma } from '@/lib/prisma'
import { notFound } from 'next/navigation'
import Navbar from '@/components/layout/Navbar'
import StarRating from '@/components/ui/StarRating'
import Link from 'next/link'

interface Props {
  params: { id: string }
}

export default async function ProviderPage({ params }: Props) {
  const provider = await prisma.provider.findUnique({
    where: { id: params.id },
    include: {
      user: true,
      reviews: {
        include: { client: true },
        orderBy: { createdAt: 'desc' },
      },
      services: {
        where: { status: 'completed' },
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { category: true },
      },
    },
  })

  if (!provider) notFound()

  const completedCount = await prisma.serviceRequest.count({
    where: { providerId: provider.id, status: 'completed' },
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar - Profile */}
          <div className="space-y-5">
            <div className="card p-6 text-center">
              <div className="w-24 h-24 bg-gradient-to-br from-sky-400 to-sky-600 rounded-full flex items-center justify-center text-white text-4xl font-bold mx-auto mb-4">
                {provider.user.name?.charAt(0)}
              </div>
              <h1 className="text-xl font-bold text-gray-900">{provider.user.name}</h1>
              <div className="flex items-center justify-center gap-1 mt-2">
                <StarRating value={Math.round(provider.rating)} readonly size="sm" />
                <span className="text-sm text-gray-500 ml-1">{provider.rating.toFixed(1)}</span>
              </div>
              <div className="flex justify-center gap-3 mt-3">
                {provider.verified && (
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">✓ Verificado</span>
                )}
                {provider.premium && (
                  <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-medium">⭐ Premium</span>
                )}
              </div>
              {provider.available ? (
                <div className="mt-3 flex items-center justify-center gap-1 text-green-600 text-sm">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" /> Disponível agora
                </div>
              ) : (
                <div className="mt-3 text-gray-400 text-sm">Indisponível no momento</div>
              )}
            </div>

            {/* Stats */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-700 mb-4 text-sm">Estatísticas</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Serviços concluídos</span>
                  <span className="font-semibold text-gray-900">{completedCount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Avaliações</span>
                  <span className="font-semibold text-gray-900">{provider.totalReviews}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Nota média</span>
                  <span className="font-semibold text-gray-900">⭐ {provider.rating.toFixed(1)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Membro desde</span>
                  <span className="font-semibold text-gray-900">{new Date(provider.createdAt).getFullYear()}</span>
                </div>
              </div>
            </div>

            {/* Contact */}
            {provider.user.phone && (
              <div className="card p-5">
                <h3 className="font-semibold text-gray-700 mb-3 text-sm">Contato</h3>
                <p className="text-sm text-gray-600">📞 {provider.user.phone}</p>
                <p className="text-sm text-gray-600 mt-1">📍 {provider.user.city}</p>
              </div>
            )}

            <Link href={`/solicitacoes/nova?provider=${provider.id}`} className="btn-primary w-full py-3 text-center block">
              Solicitar Serviço
            </Link>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-5">
            {/* Bio */}
            {provider.bio && (
              <div className="card p-6">
                <h2 className="font-bold text-gray-900 mb-3">Sobre</h2>
                <p className="text-gray-600 leading-relaxed">{provider.bio}</p>
              </div>
            )}

            {/* Skills */}
            {provider.skills.length > 0 && (
              <div className="card p-6">
                <h2 className="font-bold text-gray-900 mb-3">Especialidades</h2>
                <div className="flex flex-wrap gap-2">
                  {provider.skills.map((skill) => (
                    <span key={skill} className="bg-sky-50 text-sky-700 border border-sky-200 px-3 py-1.5 rounded-full text-sm font-medium">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews */}
            <div className="card p-6">
              <h2 className="font-bold text-gray-900 mb-4">
                Avaliações ({provider.reviews.length})
              </h2>
              {provider.reviews.length === 0 ? (
                <p className="text-gray-400 text-sm text-center py-6">Nenhuma avaliação ainda.</p>
              ) : (
                <div className="space-y-4">
                  {provider.reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-50 pb-4 last:border-0 last:pb-0">
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 font-bold text-sm shrink-0">
                          {review.client.name?.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-gray-900 text-sm">{review.client.name}</span>
                            <div className="flex">
                              {[1,2,3,4,5].map(s => (
                                <span key={s} className={`text-xs ${s <= review.rating ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                              ))}
                            </div>
                            <span className="text-xs text-gray-400">
                              {new Date(review.createdAt).toLocaleDateString('pt-BR')}
                            </span>
                          </div>
                          {review.comment && (
                            <p className="text-gray-600 text-sm mt-1">{review.comment}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
