import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StatusBadge from '@/components/ui/StatusBadge'
import Link from 'next/link'

export default async function PagamentoPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const payments = await prisma.payment.findMany({
    where: { clientId: session.user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      service: {
        include: {
          category: true,
          provider: { include: { user: true } },
        },
      },
    },
  })

  const totalSpent = payments
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0)

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Histórico de Pagamentos</h1>
          <p className="text-gray-500 mt-1">Todas as suas transações</p>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="card p-5 text-center">
            <p className="text-sm text-gray-500">Total gasto</p>
            <p className="text-2xl font-extrabold text-gray-900 mt-1">R$ {totalSpent.toFixed(2)}</p>
          </div>
          <div className="card p-5 text-center">
            <p className="text-sm text-gray-500">Pagamentos</p>
            <p className="text-2xl font-extrabold text-emerald-600 mt-1">
              {payments.filter(p => p.status === 'completed').length}
            </p>
          </div>
          <div className="card p-5 text-center">
            <p className="text-sm text-gray-500">Pendentes</p>
            <p className="text-2xl font-extrabold text-yellow-600 mt-1">
              {payments.filter(p => p.status === 'pending').length}
            </p>
          </div>
        </div>

        {/* Payment list */}
        {payments.length === 0 ? (
          <div className="card p-16 text-center">
            <span className="text-5xl block mb-3">💳</span>
            <h3 className="text-lg font-semibold text-gray-700">Nenhum pagamento ainda</h3>
            <p className="text-gray-400 text-sm mt-1">Seus pagamentos aparecerão aqui.</p>
            <Link href="/catalogo" className="btn-primary mt-4 inline-block">Explorar Serviços</Link>
          </div>
        ) : (
          <div className="card overflow-hidden">
            <div className="divide-y divide-gray-50">
              {payments.map((payment) => (
                <div key={payment.id} className="px-6 py-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xl shrink-0 ${
                      payment.method === 'pix' ? 'bg-sky-100' : 'bg-purple-100'
                    }`}>
                      {payment.method === 'pix' ? '⚡' : '💳'}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{payment.service.title}</p>
                      <p className="text-sm text-gray-500">
                        {payment.service.category.name}
                        {payment.service.provider && ` · ${payment.service.provider.user.name}`}
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {payment.method.toUpperCase()} · {new Date(payment.createdAt).toLocaleDateString('pt-BR', { dateStyle: 'long' })}
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-gray-900 text-lg">R$ {payment.amount.toFixed(2)}</p>
                    <StatusBadge status={payment.status} />
                    <Link href={`/solicitacoes/${payment.serviceId}`}
                      className="text-xs text-sky-600 hover:underline mt-1 block">
                      Ver serviço →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
