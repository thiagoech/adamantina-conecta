'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'

export default function CadastroPage() {
  const searchParams = useSearchParams()
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    role: searchParams.get('role') || 'client',
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [apiError, setApiError] = useState('')
  const router = useRouter()

  const validate = () => {
    const e: Record<string, string> = {}
    if (form.name.length < 2) e.name = 'Nome muito curto'
    if (!form.email.includes('@')) e.email = 'E-mail inválido'
    if (form.password.length < 6) e.password = 'Senha deve ter pelo menos 6 caracteres'
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Senhas não coincidem'
    return e
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const v = validate()
    setErrors(v)
    if (Object.keys(v).length > 0) return

    setLoading(true)
    setApiError('')
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name, email: form.email, password: form.password, role: form.role, phone: form.phone }),
    })
    setLoading(false)

    if (res.ok) {
      router.push('/login?registered=1')
    } else {
      const data = await res.json()
      setApiError(data.error || 'Erro ao criar conta.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/home" className="inline-flex items-center gap-2 mb-6">
            <span className="text-3xl">🏙️</span>
            <span className="font-bold text-gray-900 text-xl">Adamantina <span className="text-sky-600">Conecta</span></span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Criar conta grátis</h1>
          <p className="text-gray-500 mt-1">Junte-se a Adamantina Conecta</p>
        </div>

        <div className="card p-8">
          {/* Role Toggle */}
          <div className="flex rounded-lg border border-gray-200 p-1 mb-6 gap-1">
            {(['client', 'provider'] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setForm({ ...form, role: r })}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                  form.role === r ? 'bg-sky-600 text-white' : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {r === 'client' ? '👤 Sou Cliente' : '🔧 Sou Prestador'}
              </button>
            ))}
          </div>

          {apiError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">{apiError}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Nome completo</label>
              <input type="text" required className="input" placeholder="João Silva" value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })} />
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="label">E-mail</label>
              <input type="email" required className="input" placeholder="seu@email.com" value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })} />
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>
            <div>
              <label className="label">Telefone (opcional)</label>
              <input type="tel" className="input" placeholder="(18) 99999-9999" value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div>
              <label className="label">Senha</label>
              <input type="password" required className="input" placeholder="Mínimo 6 caracteres" value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })} />
              {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
            </div>
            <div>
              <label className="label">Confirmar senha</label>
              <input type="password" required className="input" placeholder="••••••••" value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })} />
              {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full py-3 mt-2 disabled:opacity-50">
              {loading ? 'Criando conta...' : 'Criar conta'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-gray-500 mt-6">
          Já tem conta?{' '}
          <Link href="/login" className="text-sky-600 font-medium hover:underline">Entrar</Link>
        </p>
      </div>
    </div>
  )
}
