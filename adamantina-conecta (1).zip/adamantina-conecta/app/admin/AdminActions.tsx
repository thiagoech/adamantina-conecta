'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

interface Props {
  providerId: string
  verified: boolean
  premium: boolean
}

export default function AdminActions({ providerId, verified, premium }: Props) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  const update = async (data: object) => {
    setLoading(true)
    await fetch(`/api/admin/providers/${providerId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
    setLoading(false)
    router.refresh()
  }

  return (
    <div className="flex gap-2 flex-wrap">
      <button
        onClick={() => update({ verified: !verified })}
        disabled={loading}
        className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors disabled:opacity-50 ${
          verified ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-green-100 text-green-700 hover:bg-green-200'
        }`}
      >
        {verified ? 'Revogar' : '✓ Verificar'}
      </button>
      <button
        onClick={() => update({ premium: !premium })}
        disabled={loading}
        className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors disabled:opacity-50 ${
          premium ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
        }`}
      >
        {premium ? 'Remover Premium' : '⭐ Premium'}
      </button>
    </div>
  )
}
