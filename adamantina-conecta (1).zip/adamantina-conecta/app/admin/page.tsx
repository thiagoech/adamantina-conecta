import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/layout/Navbar'
import StatusBadge from '@/components/ui/StatusBadge'
import Link from 'next/link'
import AdminActions from './AdminActions'

export default async function AdminPage() {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== 'admin') redirect('/dashboard')

  const [
    totalUsers, totalProviders, totalRequests, totalRevenue,
    recentRequests, recentUsers, providers
  ] = await Promise.all([
    prisma.user.count(),
    prisma.provider.count(),
    prisma.serviceRequest.count(),
    prisma.payment.aggregate({ where: { status: 'completed' }, _sum: { amount: true } }),
    prisma.serviceRequest.findMany({
      take: 10, orderBy: { createdAt: 'desc' },
      include: { category: true, client: true, provider: { include: { user: true } } },
    }),
    prisma.user.findMany({ take: 10, orderBy: { createdAt: 'desc' } }),
    prisma.provider.findMany({
      include: { user: true },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
  ])

  const statusCounts = await prisma.serviceRequest.groupBy({
    by: ['status'],
    _count: { status: true },
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Painel Administrativo</h1>
          <p className="text-gray-500 mt-1">Gestão completa do Adamantina Conecta</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card p-5 border-l-4 border-sky-500">
            <p className="text-sm text-gray-500">Total de usuários</p>
            <p className="text-3xl font-extrabold text-gray-900 mt-1">{totalUsers}</p>
          </div>
          <div className="card p-5 border-l-4 border-emerald-500">
            <p className="text-sm text-gray-500">Prestadores</p>
            <p className="text-3xl font-extrabold text-gray-900 mt-1">{totalProviders}</p>
          </div>
          <div className="card p-5 border-l-4 border-purple-500">
            <p className="text-sm text-gray-500">Solicitações</p>
            <p className="text-3xl font-extrabold text-gray-900 mt-1">{totalRequests}</p>
          </div>
          <div className="card p-5 border-l-4 border-yellow-500">
            <p className="text-sm text-gray-500">Receita total</p>
            <p className="text-3xl font-extrabold text-gray-900 mt-1">
              R$ {(totalRevenue._sum.amount || 0).toFixed(2)}
            </p>
          </div>
        </div>

        {/* Status breakdown */}
        <div className="card p-5 mb-8">
          <h2 className="font-bold text-gray-900 mb-4">Status das Solicitações</h2>
          <div className="flex flex-wrap gap-3">
            {statusCounts.map((s) => (
              <div key={s.status} className="flex items-center gap-2">
                <StatusBadge status={s.status} />
                <span className="font-bold text-gray-900">{s._count.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Recent Requests */}
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900">Solicitações Recentes</h2>
            </div>
            <div className="divide-y divide-gray-50">
              {recentRequests.map((req) => (
                <Link key={req.id} href={`/solicitacoes/${req.id}`}
                  className="flex items-center gap-3 px-5 py-3 hover:bg-gray-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">{req.title}</p>
                    <p className="text-xs text-gray-400 truncate">{req.client.name} · {req.category.name}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <StatusBadge status={req.status} />
                    {req.price && <p className="text-xs text-gray-500 mt-1">R$ {req.price.toFixed(2)}</p>}
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Users */}
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900">Usuários Recentes</h2>
            </div>
            <div className="divide-y divide-gray-50">
              {recentUsers.map((user) => (
                <div key={user.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="w-8 h-8 bg-sky-100 rounded-full flex items-center justify-center text-sky-700 font-bold text-sm shrink-0">
                    {user.name?.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">{user.name}</p>
                    <p className="text-xs text-gray-400 truncate">{user.email}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    user.role === 'provider' ? 'bg-emerald-100 text-emerald-700' :
                    user.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {user.role}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Provider Management */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="font-bold text-gray-900">Gerenciar Prestadores</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="text-left px-5 py-3 text-gray-500 font-medium">Prestador</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-medium">Avaliação</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-medium">Status</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {providers.map((provider) => (
                  <tr key={provider.id} className="hover:bg-gray-50">
                    <td className="px-5 py-3">
                      <p className="font-medium text-gray-900">{provider.user.name}</p>
                      <p className="text-gray-400 text-xs">{provider.user.email}</p>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1">
                        <span className="text-yellow-400">★</span>
                        <span>{provider.rating.toFixed(1)}</span>
                        <span className="text-gray-400">({provider.totalReviews})</span>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex gap-1 flex-wrap">
                        {provider.verified && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Verificado</span>}
                        {provider.premium && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">Premium</span>}
                        {!provider.verified && <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">Pendente</span>}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <AdminActions
                        providerId={provider.id}
                        verified={provider.verified}
                        premium={provider.premium}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
