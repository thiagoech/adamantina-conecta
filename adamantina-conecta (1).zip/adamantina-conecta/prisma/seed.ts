import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Iniciando seed...')

  // Limpar dados existentes
  await prisma.notification.deleteMany()
  await prisma.payment.deleteMany()
  await prisma.review.deleteMany()
  await prisma.serviceRequest.deleteMany()
  await prisma.provider.deleteMany()
  await prisma.user.deleteMany()
  await prisma.serviceCategory.deleteMany()
  await prisma.subscriptionPlan.deleteMany()

  // Categorias
  const categories = await Promise.all([
    prisma.serviceCategory.create({ data: { name: 'Limpeza Residencial', description: 'Serviços de limpeza para casas e apartamentos em Adamantina-SP', icon: '🧹' } }),
    prisma.serviceCategory.create({ data: { name: 'Reparos Elétricos', description: 'Instalações e reparos elétricos residenciais e comerciais', icon: '⚡' } }),
    prisma.serviceCategory.create({ data: { name: 'Jardinagem', description: 'Cuidado com jardins, poda e paisagismo', icon: '🌳' } }),
    prisma.serviceCategory.create({ data: { name: 'Manutenção de Veículos', description: 'Mecânica, funilaria e serviços automotivos', icon: '🚗' } }),
    prisma.serviceCategory.create({ data: { name: 'Serviços Domésticos', description: 'Babá, cozinheiro, passadeira e cuidados gerais', icon: '🏠' } }),
    prisma.serviceCategory.create({ data: { name: 'Encanamento', description: 'Reparos hidráulicos e instalações', icon: '🔧' } }),
    prisma.serviceCategory.create({ data: { name: 'Pintura', description: 'Pintura residencial e comercial', icon: '🎨' } }),
    prisma.serviceCategory.create({ data: { name: 'Informática', description: 'Suporte técnico, formatação e redes', icon: '💻' } }),
  ])

  // Planos
  await prisma.subscriptionPlan.createMany({
    data: [
      { name: 'Premium Cliente', description: 'Acesso prioritário a prestadores verificados', price: 9.99, features: ['Prioridade em solicitações', 'Suporte 24/7', 'Desconto de 10% em serviços', 'Histórico ilimitado'], type: 'premium' },
      { name: 'Empresarial', description: 'Para empresas locais de Adamantina', price: 29.99, features: ['Múltiplos usuários', 'Relatórios detalhados', 'API de integração', 'Gerente de conta'], type: 'business' },
    ],
  })

  const hashedPassword = await bcrypt.hash('senha123', 10)

  // Admin
  await prisma.user.create({
    data: {
      email: 'admin@adamantina.com',
      name: 'Admin',
      password: hashedPassword,
      role: 'admin',
      phone: '(18) 3521-0000',
      city: 'Adamantina-SP',
    },
  })

  // Clientes
  const cliente1 = await prisma.user.create({
    data: {
      email: 'joao@gmail.com',
      name: 'João Silva',
      password: hashedPassword,
      role: 'client',
      phone: '(18) 99999-1111',
      address: 'Rua das Flores, 123',
      city: 'Adamantina-SP',
    },
  })

  const cliente2 = await prisma.user.create({
    data: {
      email: 'maria@gmail.com',
      name: 'Maria Oliveira',
      password: hashedPassword,
      role: 'client',
      phone: '(18) 99999-2222',
      address: 'Av. Brasil, 456',
      city: 'Adamantina-SP',
    },
  })

  // Prestadores
  const provUser1 = await prisma.user.create({
    data: {
      email: 'carlos@gmail.com',
      name: 'Carlos Pereira',
      password: hashedPassword,
      role: 'provider',
      phone: '(18) 99888-1111',
      address: 'Rua do Comércio, 789',
      city: 'Adamantina-SP',
    },
  })

  const provider1 = await prisma.provider.create({
    data: {
      userId: provUser1.id,
      bio: 'Especialista em limpeza residencial com 10 anos de experiência em Adamantina. Trabalho com produtos ecológicos e atendo com excelência.',
      skills: ['Limpeza', 'Organização', 'Faxina pesada'],
      rating: 4.8,
      totalReviews: 24,
      verified: true,
      premium: true,
    },
  })

  const provUser2 = await prisma.user.create({
    data: {
      email: 'roberto@gmail.com',
      name: 'Roberto Eletricista',
      password: hashedPassword,
      role: 'provider',
      phone: '(18) 99888-2222',
      city: 'Adamantina-SP',
    },
  })

  const provider2 = await prisma.provider.create({
    data: {
      userId: provUser2.id,
      bio: 'Eletricista credenciado com CREA. Atendo residências e comércios. Instalações, reparos e laudos elétricos.',
      skills: ['Eletricidade residencial', 'Quadro elétrico', 'CCTV', 'Iluminação'],
      rating: 4.6,
      totalReviews: 18,
      verified: true,
    },
  })

  const provUser3 = await prisma.user.create({
    data: {
      email: 'ana@gmail.com',
      name: 'Ana Jardins',
      password: hashedPassword,
      role: 'provider',
      phone: '(18) 99888-3333',
      city: 'Adamantina-SP',
    },
  })

  await prisma.provider.create({
    data: {
      userId: provUser3.id,
      bio: 'Paisagista e jardineira com formação técnica. Criação e manutenção de jardins residenciais.',
      skills: ['Paisagismo', 'Poda', 'Irrigação', 'Plantas ornamentais'],
      rating: 4.9,
      totalReviews: 31,
      verified: true,
      premium: true,
    },
  })

  // Solicitações de serviço
  const req1 = await prisma.serviceRequest.create({
    data: {
      title: 'Limpeza completa da casa',
      description: 'Preciso de uma limpeza geral na minha casa de 3 quartos, incluindo banheiros e cozinha.',
      categoryId: categories[0].id,
      clientId: cliente1.id,
      providerId: provider1.id,
      status: 'completed',
      price: 150.00,
      location: 'Rua das Flores, 123, Adamantina-SP',
      scheduledAt: new Date('2024-01-15'),
    },
  })

  const req2 = await prisma.serviceRequest.create({
    data: {
      title: 'Troca de tomadas e interruptores',
      description: 'Algumas tomadas e interruptores estão com defeito. Preciso trocar uns 5 pontos.',
      categoryId: categories[1].id,
      clientId: cliente2.id,
      providerId: provider2.id,
      status: 'in_progress',
      price: 200.00,
      location: 'Av. Brasil, 456, Adamantina-SP',
      scheduledAt: new Date('2024-01-20'),
    },
  })

  await prisma.serviceRequest.create({
    data: {
      title: 'Manutenção do jardim',
      description: 'Preciso de poda de árvores e manutenção geral do jardim.',
      categoryId: categories[2].id,
      clientId: cliente1.id,
      status: 'open',
      location: 'Rua das Flores, 123, Adamantina-SP',
    },
  })

  // Avaliações
  await prisma.review.create({
    data: {
      rating: 5,
      comment: 'Excelente serviço! Carlos foi muito pontual e caprichoso na limpeza. Recomendo muito!',
      clientId: cliente1.id,
      providerId: provider1.id,
      serviceId: req1.id,
    },
  })

  // Pagamento
  await prisma.payment.create({
    data: {
      amount: 150.00,
      method: 'pix',
      status: 'completed',
      clientId: cliente1.id,
      serviceId: req1.id,
      pixCode: '00020126580014br.gov.bcb.pix0136mock-pix-key-adamantina5204000053039865406150.005802BR5925ADAMANTINA CONECTA6009Adamantina62070503***6304MOCK',
    },
  })

  // Notificações
  await prisma.notification.createMany({
    data: [
      { userId: cliente1.id, message: 'Seu serviço de limpeza foi concluído! Avalie o prestador.', type: 'success' },
      { userId: provUser1.id, message: 'Você recebeu uma nova solicitação de serviço!', type: 'info' },
      { userId: cliente2.id, message: 'Roberto aceitou sua solicitação de reparo elétrico.', type: 'success' },
    ],
  })

  console.log('✅ Seed concluído com sucesso!')
  console.log('')
  console.log('Usuários criados:')
  console.log('  Admin:     admin@adamantina.com / senha123')
  console.log('  Cliente:   joao@gmail.com / senha123')
  console.log('  Cliente:   maria@gmail.com / senha123')
  console.log('  Prestador: carlos@gmail.com / senha123')
  console.log('  Prestador: roberto@gmail.com / senha123')
  console.log('  Prestador: ana@gmail.com / senha123')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
