'use client'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useState } from 'react'

export default function Navbar() {
  const { data: session } = useSession()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/home" className="flex items-center gap-2">
            <span className="text-2xl">🏙️</span>
            <span className="font-bold text-gray-900 text-lg">Adamantina <span className="text-sky-600">Conecta</span></span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/catalogo" className="text-gray-600 hover:text-sky-600 font-medium transition-colors">Serviços</Link>
            {session ? (
              <>
                <Link href="/dashboard" className="text-gray-600 hover:text-sky-600 font-medium transition-colors">Dashboard</Link>
                {session.user.role === 'admin' && (
                  <Link href="/admin" className="text-gray-600 hover:text-sky-600 font-medium transition-colors">Admin</Link>
                )}
                <div className="relative">
                  <button
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="flex items-center gap-2 text-gray-700 hover:text-sky-600 font-medium"
                  >
                    <div className="w-8 h-8 bg-sky-100 rounded-full flex items-center justify-center text-sky-700 font-bold text-sm">
                      {session.user.name?.charAt(0).toUpperCase()}
                    </div>
                    <span>{session.user.name?.split(' ')[0]}</span>
                    <span>▾</span>
                  </button>
                  {menuOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50">
                      <Link href="/perfil" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50" onClick={() => setMenuOpen(false)}>Meu Perfil</Link>
                      <Link href="/solicitacoes" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50" onClick={() => setMenuOpen(false)}>Minhas Solicitações</Link>
                      <hr className="my-1" />
                      <button
                        onClick={() => signOut({ callbackUrl: '/login' })}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                      >
                        Sair
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link href="/login" className="text-gray-600 hover:text-sky-600 font-medium transition-colors">Entrar</Link>
                <Link href="/cadastro" className="btn-primary text-sm">Cadastrar</Link>
              </>
            )}
          </nav>

          {/* Mobile menu button */}
          <button className="md:hidden p-2" onClick={() => setMenuOpen(!menuOpen)}>
            <span className="text-gray-600">☰</span>
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-gray-100 py-3 space-y-2">
            <Link href="/catalogo" className="block px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Serviços</Link>
            {session ? (
              <>
                <Link href="/dashboard" className="block px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Dashboard</Link>
                <Link href="/perfil" className="block px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Meu Perfil</Link>
                <button onClick={() => signOut({ callbackUrl: '/login' })} className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg">Sair</button>
              </>
            ) : (
              <>
                <Link href="/login" className="block px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Entrar</Link>
                <Link href="/cadastro" className="block px-4 py-2 text-sky-600 font-medium hover:bg-sky-50 rounded-lg">Cadastrar</Link>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  )
}
