const statusMap: Record<string, { label: string; className: string }> = {
  open: { label: 'Aberto', className: 'badge-open' },
  assigned: { label: 'Atribuído', className: 'badge-assigned' },
  in_progress: { label: 'Em Andamento', className: 'badge-in_progress' },
  completed: { label: 'Concluído', className: 'badge-completed' },
  cancelled: { label: 'Cancelado', className: 'badge-cancelled' },
  pending: { label: 'Pendente', className: 'badge-assigned' },
  failed: { label: 'Falhou', className: 'badge-cancelled' },
}

export default function StatusBadge({ status }: { status: string }) {
  const s = statusMap[status] ?? { label: status, className: 'badge-open' }
  return <span className={s.className}>{s.label}</span>
}
